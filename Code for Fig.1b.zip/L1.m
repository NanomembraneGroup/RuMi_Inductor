function L = L1(a, b, T, l)
    L = 200*l * (log((2*l)/(a+b)) + 0.25049 + 0.25*T + (a+b)/(3*l));
end